 <div class="container">
	
	<div id="post" class="panel panel-danger">
	 	<div class="panel-heading">
	 		<p class="panel-title"><?php echo $post['m_head']; ?></p>
	 	</div> <!-- Panel Heading closes here -->
	 	<div class="panel-body">
	 		<p><?php echo $post['body_formatted']; ?></p>
	 	</div> <!-- Panel Body closes here -->
	 </div>	<!-- Panel closes here -->
 </div> 