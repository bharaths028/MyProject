<?php include('templates/header.php'); // Page Header ?>

<?php include('views/'.$view['name'].'.php'); // View Type ?>

<?php include('templates/footer.php'); // Page Footer ?>	