</div>	

		<!-- Footer -->
		
		<footer>
  <!--<a class="up-arrow" href="#myPage" data-toggle="tooltip" title="TO TOP">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a><br><br>-->
  <p>Theme Made By <a href="https://www.facebook.com/bharaths05" data-toggle="tooltip" title="Visit w3schools">FreeLancer</a></p> 
</footer>
		<?php if($debug == 1) { include('widgets/debug.php'); } ?>
	</body>
</html>
