<?php 

	include('templates/header.php');
	include('views/'.$page.'.php');	
	include('templates/footer.php'); 

?>		

			

