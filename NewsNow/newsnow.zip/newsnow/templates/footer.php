

</div> <!-- End Wrap -->


		<footer id="footer" class="container-fluid text-center">
			<a href="#myPage" title="To Top">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a>
		  <p>Copyright <i class="fa fa-copyright"></i> 2016 <a href="http://xprs.imcreator.com/free/bharaths028/bharath-portfolio/bharath-portfolio" data-toggle="tooltip" title="Visit w3schools">FreeLancer</a></p> 
		  
		</footer>

		<?php if($debug == 1) { include('widgets/debug.php'); } ?>

	</body>
</html>

