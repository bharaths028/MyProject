<div id="console-debug">

	<?php

		$all_vars = get_defined_vars();

	?>

	<?php	//print_r($all_vars); ?>

	<h1>Path Array</h1>

	<pre>
		<?php	print_r($path); ?>
		
	</pre>


	<h1>Get</h1>

	<pre>
		<?php	print_r($_GET); ?>
		
	</pre>

	<h1>Post</h1>

	<pre>
		<?php	print_r($_POST); ?>
		
	</pre>

	<h1>Page Array</h1>

	<pre>
		<?php	print_r($page); ?>
	</pre>

	

	<h1>Post Array</h1>

	<pre>
		<?php	print_r($post); ?>
		
	</pre>

	<h1>View Array</h1>

	<pre>
		<?php	print_r($view); ?>
	</pre>

</div>